﻿using System;

using System.Collections.Generic;

using System.IO;

using System.Linq;

using System.Runtime.InteropServices.WindowsRuntime;

using Windows.Foundation;

using Windows.Foundation.Collections;

using Windows.UI.Xaml;

using Windows.UI.Xaml.Controls;

using Windows.UI.Xaml.Controls.Primitives;

using Windows.UI.Xaml.Data;

using Windows.UI.Xaml.Input;

using Windows.UI.Xaml.Media;

using Windows.UI.Xaml.Navigation;

using Microsoft.Maker.RemoteWiring;

using Microsoft.Maker.Serial;

using System.Diagnostics;

using System.Dynamic;
using System.Net.Http;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace blink
{
    public sealed partial class MainPage : Page
    {
        UsbSerial usb;                          //Handle the USB connction
        RemoteDevice arduino;                   //Handle the arduino
        private DispatcherTimer textSoundsensorTimer;     //Timer for the LED to textSoundsensor every one second
        ushort light = 0;       //Pin number of the on Keyboard
        ushort waist = 0;
        ushort neck = 0;

        public MainPage()
        {
            this.InitializeComponent();

            //USB VID and PID of the "Arduino Expansion Shield for Raspberry Pi B+"
            usb = new UsbSerial("VID_2341", "PID_8036");

            //Arduino RemoteDevice Constractor via USB.
            arduino = new RemoteDevice(usb);
            //Add DeviceReady callback when connecting successfully
        
            Debug.WriteLine("hih1111i");
            arduino.DeviceReady += onDeviceReady;

            //Baudrate on 57600 and SerialConfig.8N1 is the default config for Arduino devices over USB
            usb.begin(57600, SerialConfig.SERIAL_8N1);
        }

        private void onDeviceReady()
        {
            //After device is ready this function will be evoked.

            //Debug message "Device Ready" will be shown in the "Output" dialog.
            Debug.WriteLine("Device Ready");

            var action = Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, new Windows.UI.Core.DispatchedHandler(() =>
            {
                setup();
            }));
        }

        private void setup()
        {
            //Set the pin mode of the led.

            arduino.pinMode("A5", PinMode.ANALOG);
            arduino.pinMode("A4", PinMode.ANALOG);
            arduino.pinMode("A3", PinMode.ANALOG);
            //Set the timer to schedule textSoundsensor() every one second.
            textSoundsensorTimer = new DispatcherTimer();
            textSoundsensorTimer.Interval = TimeSpan.FromMilliseconds(3000);
            textSoundsensorTimer.Tick += textSoundsensor;
            textSoundsensorTimer.Start();
        }

        private void textSoundsensor(object sender, object e)
        {

            light = arduino.analogRead("A5");
            waist = arduino.analogRead("A4");
            neck = arduino.analogRead("A3");
            POSTreq(light, waist, neck);
            Debug.WriteLine("light1 : " + light + " waist : " + waist + " neck : " + neck);

        }
        public async void POSTreq(ushort light, ushort waist, ushort neck)
        {
            Uri requestUri = new Uri("http://52.231.29.193/sensing");
            dynamic dynamicJson = new ExpandoObject();
            dynamicJson.id = "psogv0308".ToString();
            dynamicJson.light = light;
            dynamicJson.waist = waist;
            dynamicJson.neck = neck;
            string json = "";
            json = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicJson);
            var objClint = new System.Net.Http.HttpClient();
            System.Net.Http.HttpResponseMessage respon = await objClint.PostAsync(requestUri, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
            string responJsonText = await respon.Content.ReadAsStringAsync();
        }
    }
}